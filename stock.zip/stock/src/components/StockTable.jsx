import React from 'react';
import { useTable, usePagination } from 'react-table';

function StockTable({ data }) {
  const columns = React.useMemo(
    () => [
      {
        Header: 'Date',
        accessor: 'date',
      },
      {
        Header: 'Open Price',
        accessor: 'open',
      },
      {
        Header: 'High Price',
        accessor: 'high',
      },
      {
        Header: 'Low Price',
        accessor: 'low',
      },
      {
        Header: 'Close Price',
        accessor: 'close',
      },
    ],
    []
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    prepareRow,

    // New pagination-related variables
    nextPage,
    previousPage,
    canPreviousPage,
    canNextPage,
    pageOptions,
    state: { pageIndex },
  } = useTable(
    {
      columns,
      data,
      initialState: { pageIndex: 0 }, // Initial page index
    },
    usePagination // Use pagination plugin
  );

  return (
    <div>
      <div
        {...getTableProps()}
        style={{
          width: 'calc(100vw - 300px)', // Adjust width according to your needs
          overflowX: 'auto', // Enable horizontal scroll
          margin: '0 auto', // Center the table horizontally
        }}
      >
        <table style={{ borderCollapse: 'collapse', minWidth: '100%' }}>
          <thead>
            {headerGroups.map(headerGroup => (
              <tr {...headerGroup.getHeaderGroupProps()}>
                {headerGroup.headers.map(column => (
                  <th
                    {...column.getHeaderProps()}
                    style={{
                      borderBottom: '2px solid black',
                      background: 'aliceblue',
                      padding: '8px',
                      textAlign: 'left',
                    }}
                  >
                    {column.render('Header')}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody {...getTableBodyProps()}>
            {page.map(row => {
              prepareRow(row);
              return (
                <tr {...row.getRowProps()} key={row.id}>
                  {row.cells.map(cell => {
                    return (
                      <td
                        {...cell.getCellProps()}
                        style={{
                          padding: '8px',
                          borderBottom: '1px solid black',
                        }}
                      >
                        {cell.render('Cell')}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', paddingTop: '10px', paddingRight: '150px' }}>
        <button onClick={() => previousPage()} disabled={!canPreviousPage} style={{ marginRight: '10px' }}>
          &lt; Previous
        </button>
        <span>
          Page{' '}
          <strong>
            {pageIndex + 1} of {pageOptions.length}
          </strong>{' '}
        </span>
        <button onClick={() => nextPage()} disabled={!canNextPage} style={{ marginLeft: '10px' }}>
          Next &gt;
        </button>
      </div>

    </div>
  );
}

export default StockTable;
