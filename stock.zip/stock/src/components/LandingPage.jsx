// LandingPage.js
import React from 'react';

const LandingPage = ({ onStartSearch }) => {
  return (
    <div style={{display: 'flex', flexDirection: 'column',alignItems: 'center',justifyContent: 'center',minHeight: '100vh'}}>
      <h1>Welcome to Stock Market</h1>
      <p>Enter a stock symbol to get started</p>
      <button onClick={onStartSearch}>Get Started</button>
    </div>
  );
};

export default LandingPage;
