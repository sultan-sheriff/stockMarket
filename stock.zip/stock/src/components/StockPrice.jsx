import React from 'react';

function StockHeader({ symbol, currentPrice }) {
  return (
    <table style={{ width: '100%', marginBottom: '16px' }}>
      <thead>
        <tr>
          <th colSpan="2" style={{ textAlign: 'left' }}>Stock Price for {symbol}</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Price:</td>
          <td>{currentPrice}</td>
        </tr>
      </tbody>
    </table>
  );
}

export default StockHeader;
