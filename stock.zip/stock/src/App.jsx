import './App.css';
import Header from './components/Header';
import React, { useState } from 'react';
import axios from 'axios'
import LandingPage from './components/LandingPage';
import StockTable from './components/StockTable';

function App() {
  const [symbol, setSymbol] = useState("")
  const [currentPrice, setCurrentPrice] = useState(null);
  const [weeklyPrices, setWeeklyPrices] = useState([]);
  const [showLandingPage, setShowLandingPage] = useState(true);

  const API_KEY = '63BY4299P3Z2ACFN';

  const fetchStockPrice = async (name) => {
    try {
      const response = await axios.get(
        `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${name}&apikey=${API_KEY}`
      );
      const data = response.data['Global Quote'];
      setCurrentPrice(data['05. price']);

      const weeklyPriceResponse = await axios.get(
        `https://www.alphavantage.co/query?function=TIME_SERIES_WEEKLY&symbol=${name}&apikey=${API_KEY}`
      );
      const weeklyPriceData = weeklyPriceResponse.data['Weekly Time Series'];
      const prices = Object.keys(weeklyPriceData).map(date => ({
        date: date,
        open: parseFloat(weeklyPriceData[date]['1. open']),
        high: parseFloat(weeklyPriceData[date]['2. high']),
        low: parseFloat(weeklyPriceData[date]['3. low']),
        close: parseFloat(weeklyPriceData[date]['4. close'])
      }));
      setWeeklyPrices(prices);
      setSymbol(name)
      setShowLandingPage(false)
    } catch (error) {
      console.error('Error fetching stock price:', error);
    }
  };

  return (
    <div className="App" style={{ display: "flex", flexDirection: "column" }}>
      <div style={{ height: "10vh", width: "100vw" }}>
        <Header fetchStock={fetchStockPrice} />
      </div>
      <div style={{ height: "90vh", width: "100vw" }}>
        {showLandingPage && <LandingPage onStartSearch={() => setShowLandingPage(false)} />}
        {!showLandingPage}
        {!showLandingPage && currentPrice && (
          <><div className="price-info" style={{ paddingLeft: "750px" }}>
            <h3>Current Stock Price for {symbol.toUpperCase()}</h3>
            <p style={{paddingLeft: "40px"}}>Price: {currentPrice}</p>
          </div>
            <div>
              <StockTable data={weeklyPrices} />
            </div></>
        )}
      </div>
    </div>
  );
}

export default App;
